package lab1_question4_kendalld;

public class MoneyProgramTest {

	public static void main(String[] args) {
		MoneyProgram m = new MoneyProgram();
		m.display();
	
	}

}
