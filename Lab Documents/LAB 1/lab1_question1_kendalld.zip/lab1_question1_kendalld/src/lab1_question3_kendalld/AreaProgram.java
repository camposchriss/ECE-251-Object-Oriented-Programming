package lab1_question3_kendalld;
import java.lang.Math;


public class AreaProgram {
	double a=-5;
	double area;
	public double computeArea() {
		
		area= (Math.sqrt(3)/4)*Math.pow(a,2);
		return area;
	}
	
}
