package lab1_question3_kendalld;

public class AreaProgramTest {

	public static void main(String[] args) {
		double area;
		AreaProgram A = new AreaProgram();
		area=A.computeArea();
		System.out.println("The area of the triangle is "+area);
		

	}

}
