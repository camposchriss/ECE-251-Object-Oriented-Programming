package lab1_question5_kendalld;

public class UnderstandingIFProgramTest {

	public static void main(String[] args) {
	UnderstandingIFProgram u = new UnderstandingIFProgram();
	u.question();

	}

}
