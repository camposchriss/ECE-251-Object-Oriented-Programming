package lab1_question2_kendalld;

public class StarDisplay {

	public void displayStar() {
		System.out.println("************\n************\n**\n**\n**\n************\n************\n          **\n          **\n          **\n************\n************");
	}
}
