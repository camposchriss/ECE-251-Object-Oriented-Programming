package lab1_question2_kendalld;

public class StarDisplayTest {

	public static void main(String[] args) {
		StarDisplay s = new StarDisplay();
		s.displayStar();
	}

}
