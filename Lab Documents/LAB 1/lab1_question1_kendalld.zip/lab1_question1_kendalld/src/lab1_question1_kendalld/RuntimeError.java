package lab1_question1_kendalld;

public class RuntimeError {
  public static void main(String[] args) {
    int i = 1 / 0;
  }
}


