package lab1_question1_kendalld;

public class HelloCalculatorTest {
    public static void main(String args[]) {
       HelloCalculator c = new HelloCalculator();
       c.averageThree();
       c.averageThreeFromUser();
       c.greetPerson();
        
    }
}