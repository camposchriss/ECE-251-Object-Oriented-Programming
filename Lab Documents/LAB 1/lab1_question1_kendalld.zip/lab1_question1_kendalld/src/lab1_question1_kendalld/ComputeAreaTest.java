package lab1_question1_kendalld;

public class ComputeAreaTest {

	public static void main(String[] args) {
		ComputeArea comArea = new ComputeArea();
		comArea.compute();

	}

}
