package lab1_question1_kendalld;

public class ComputeArea {

double radius;
double area;

public ComputeArea() {
	radius=20.0;
}

public void compute() {
	area= radius*radius*3.14159;
	
	System.out.println("The area for the circle of radius "+radius+" is "+area);
	
	
		
		
	}

}
