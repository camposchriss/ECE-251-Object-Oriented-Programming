/* 
 * Class: ECE 251
 * Instructor: Professor Xiaoli Yang
 * Authors: Dustin Kendall
 * Assignment: #1
 * Filename: ChangeTest.java
 * Date: 2/2/2018
 * This is the main function which calls the method change from class ChangeCalc.java
 */
package question1_ha1;
import java.util.*;

public class ChangeTest {

	public static void main(String[] args) {
		//declare new scanner object sn to accept user input throughout main
		Scanner sn = new Scanner(System.in);
		ChangeCalc calc = new ChangeCalc();
		int paid = 0;// declare variable which represents the total value of the purchase in pennies
		System.out.println("============================\n");
		GregorianCalendar today = new GregorianCalendar();
		System.out.println("Welcome to the PNW Change Calculator - Written by Dustin Kendall\n");
		System.out.println(today.getTime());
		System.out.println("=============================\n\n\n");
		System.out.println("Please enter purchase amount in pennies (i.e. if you would like to buy $1.27 enter 127): \n\n");
		paid = sn.nextInt();
		while(paid>500||paid<=0) {
			if(paid>5)
			{
				System.out.println("You do not have enough money for this purchase. Make a smaller purchase (i.e. lesse than 500 pennies):" );
				paid = sn.nextInt();
				
			}
			else
			{
				System.out.println("You did not make a purchase...Please make a purchase between 1 and 500 pennies: ");
				paid = sn.nextInt();
				
			}	
		}
			
		sn.close();
		calc.change(paid);
		
		
		
		
		
	}

}
