package question2_ha1;
import java.util.*;
/* 
 * Class: ECE 251
 * Instructor: Professor Xiaoli Yang
 * Authors: Dustin Kendall
 * Assignment: #1
 * Filename: StarDisplayTest.java
 * Date: 2/2/2018
 * This is the main function which calls the method from StarDisplay class  */

public class StarDisplayTest {

	public static void main(String[] args) {
		Scanner sn = new Scanner(System.in);//instance new scanner class object
		StarDisplay s = new StarDisplay();//instantiate new StarDisplay object to pass values to
		System.out.println("Please enter a 5 digit positive integer to be displayed: ");
		String userString = sn.nextLine();//Integer string
		
		s.displayStar(userString);//pass to display class to print banner.
		sn.close();
	}

}
