/* 
 * Class: ECE 251
 * Instructor: Professor Xiaoli Yang
 * Authors: Dustin Kendall
 * Assignment: #1
 * Filename: StarDisplay.java
 * Date: 2/2/2018
 * This is the class which formats and displays data on the prompt with asterisk  */
package question2_ha1;

public class StarDisplay {
	
        private char[] userInput;
	
	public void displayStar(String stringToNum) {
		userInput = stringToNum.toCharArray();//convert string from main method to char array
		displayStarHelper(userInput);
                
	}

	public void displayStarHelper(char[] userInput) {
		
		
            
		for(int i = 0;i<=4;i++)
		{
			switch (userInput[i])
			{
			case '5':
				System.out.println(
						"**    ********\r\n" + 
						"**    ********\r\n" + 
						"**    **    **\r\n" + 
						"**    **    **\r\n" + 
						"********    **\r\n" + 
						"********    **\r\n\n\n");
				break;
			case '2':
				System.out.println(
						"********    **\r\n" + 
						"********    **\r\n" + 
						"**    **    **\r\n" + 
						"**    **    **\r\n" + 
						"**    ********\r\n" + 
						"**    ********\r\n\n\n");
				break;
			case '6':
				System.out.println(
						"**************\r\n" + 
						"**************\r\n" + 
						"**    **    **\r\n" + 
						"**    **    **\r\n" + 
						"********    **\r\n" + 
						"********    **\r\n\n\n");
				break;
			case '1':
				System.out.println(
						"**************\r\n" + 
						"**************\r\n\n\n");
				break;
			case '3':
				System.out.println(
						
					    "**    **    **\r\n" +
					    "**    **    **\r\n"+
						"**    **    **\r\n"+
					    "**    **    **\r\n"+
					    "**************\r\n" + 
						"**************\r\n\n\n");
				break;
			case'4':
				System.out.println(
						"      ********\r\n"+
						"      ********\r\n"+
						"      **      \r\n"+
						"      **      \r\n"+
						"**************\r\n"+
						"**************\r\n\n\n");
				break;
			case '7':
				System.out.println(
						"****       ***\r\n"+
						"  ****     ***\r\n"+
						"    ****   ***\r\n"+
						"      ***  ***\r\n"+
						"        ******\r\n"+
						"          ****\r\n\n\n");
				break;
				
			case '8':
				System.out.println(
						        "**************\r\n"+
								"**************\r\n"+
								"**    **    **\r\n"+
								"**    **    **\r\n"+
								"**************\r\n"+
								"**************\r\n\n\n");
				break;
				
			case '9':
				System.out.println(
                                                                "      ********\r\n"+
								"      ********\r\n"+
								"      **    **\r\n"+
								"      **    **\r\n"+
								"**************\r\n"+
								"**************\r\n\n\n");
                                break;
                        case '0':
                                System.out.println(             "**************\r\n"+
								"**************\r\n"+
								"***        ***\r\n"+
								"***        ***\r\n"+
								"**************\r\n"+
								"**************\r\n\n\n");
                                break;
			default:
				System.out.println("\n\nThis is not a numeric character and cannot be diplayed\n\n");
                                break;
				
			}
		}
		
	}
}
