/* 
 * Class: ECE 251
 * Instructor: Professor Xiaoli Yang
 * Authors: Dustin Kendall
 * Assignment: #1
 * Filename: ChangeCalc.java
 * Date: 2/2/2018
Class which calclates least amount of items for change
 */
package question1_ha1;

public class ChangeCalc {
	private int remainder,dollars,quarters,dimes,nickels,pennies;
	/*Method change() takes an integer value (in pennies) and calculates the least amount of items give for change in
	Singles, Quarters, Dimes, Nickels, and Pennies from a purchase - assuming that all purchases are made with a five dollar bill*/
	public void change(int paid) {
		 remainder = 500-paid;
		 dollars = remainder/100;
		 quarters = (remainder - dollars*100)/25;
		 dimes = (remainder - dollars*100-quarters*25)/10;
		 nickels = (remainder - dollars*100 - quarters*25 - dimes*10)/5;
		 pennies = (remainder - dollars*100 - quarters * 25 - dimes*10 - nickels*5);
		
		System.out.printf("Your purchase of $%.2f paid with a 5 dollar bill yeilds a change of: \n", paid/100.0);
		System.out.println("\nDollar(s): " + dollars);
		System.out.println("\nQuarter(s): "+quarters);
		System.out.println("\nDime(s): "+dimes);
		System.out.println("\nNickel(s): "+ nickels);
		System.out.println("\nPennie(s): " + pennies);
		
		
		
		
	}

}
