/* 
 * Class: ECE 251
 * Instructor: Professor Xiaoli Yang
 * Authors: Dustin Kendall
 * Assignment: #1
 * Filename: StarDisplay.java
 * Date: 2/2/2018
 * This is the class which formats and displays data on the prompt with asterisk  */
package question2_ha1;

public class StarDisplay {
	
        
	
	public void displayStar(int userInput) {
		int[] a = new int[5] ;
		//first for loop turns integer into digit by digit integer array
		for(int i = 4; i>=0;i--)
		{
			a[i] = userInput%10;
			userInput = userInput/10;
			
		}
		//second for loop passes each digit of the integer array individually
		//displayStarHelper prints out stars
		for(int j = 0; j<= 4; j++)
		{
			displayStarHelper(a[j]);
		}
	
                
	}

	public void displayStarHelper(int digit) {
		
		
            //Method prints out stars for each individual digit passed to it. 
		
		
			switch (digit)
			{
			case 5:
				System.out.println(
						"**    ********\r\n" + 
						"**    ********\r\n" + 
						"**    **    **\r\n" + 
						"**    **    **\r\n" + 
						"********    **\r\n" + 
						"********    **\r\n\n\n");
				break;
			case 2:
				System.out.println(
						"********    **\r\n" + 
						"********    **\r\n" + 
						"**    **    **\r\n" + 
						"**    **    **\r\n" + 
						"**    ********\r\n" + 
						"**    ********\r\n\n\n");
				break;
			case 6:
				System.out.println(
						"**************\r\n" + 
						"**************\r\n" + 
						"**    **    **\r\n" + 
						"**    **    **\r\n" + 
						"********    **\r\n" + 
						"********    **\r\n\n\n");
				break;
			case 1:
				System.out.println(
						"**************\r\n" + 
						"**************\r\n\n\n");
				break;
			case 3:
				System.out.println(
						
					    "**    **    **\r\n" +
					    "**    **    **\r\n"+
						"**    **    **\r\n"+
					    "**    **    **\r\n"+
					    "**************\r\n" + 
						"**************\r\n\n\n");
				break;
			case 4:
				System.out.println(
						"      ********\r\n"+
						"      ********\r\n"+
						"      **      \r\n"+
						"      **      \r\n"+
						"**************\r\n"+
						"**************\r\n\n\n");
				break;
			case 7:
				System.out.println(
						"****       ***\r\n"+
						"  ****     ***\r\n"+
						"    ****   ***\r\n"+
						"      ***  ***\r\n"+
						"        ******\r\n"+
						"          ****\r\n\n\n");
				break;
				
			case 8:
				System.out.println(
						        "**************\r\n"+
								"**************\r\n"+
								"**    **    **\r\n"+
								"**    **    **\r\n"+
								"**************\r\n"+
								"**************\r\n\n\n");
				break;
				
			case 9:
				System.out.println(
                                                                "      ********\r\n"+
								"      ********\r\n"+
								"      **    **\r\n"+
								"      **    **\r\n"+
								"**************\r\n"+
								"**************\r\n\n\n");
                                break;
            case 0:
                                System.out.println(             "**************\r\n"+
								"**************\r\n"+
								"***        ***\r\n"+
								"***        ***\r\n"+
								"**************\r\n"+
								"**************\r\n\n\n");
                                break;
			default:
				System.out.println("\n\nThis is not a numeric character and cannot be diplayed\n\n");
                                break;
				
			
		}
		
	}
}
