/*
Class: ECE25100 Object Oriented Programming
Instructor: Xiaoli Yang
Author: Dustin Kendall
Assignment: 3
File Name:University.java
Date: 3.24.2018
*/
// Course Class is class which stores and modifies the Course information*/
import java.util.*;

public class Course {
	private String title, code;
	private int number;
	private ArrayList<Student> students = new ArrayList<>(12);
	public Course() {
		title = "unknown";
		code = "unknown";
		number = 0;
		students = null;
	}
	public Course( String aCode, int aNumber,String aTitle)
	{
		title = aTitle;
		code = aCode.toUpperCase();
		number = aNumber;
	}
	public String getTitle() {
		return title;
	}
	
	public String getCode() {
		return code;
	}
	public int getNumber() {
		return number;
	}
	
	public String toString() {
		return (code + number + " - " + title);
		
	}
	public ArrayList<Student> getStudents() {
		return students;
	}
	protected void addStudent(Student s) {
		students.add(s);
	}
	protected void removeStudent(Student s) {
		students.remove(s);
		
	}
	
	
	
}
