/*
Class: ECE25100 Object Oriented Programming
Instructor: Xiaoli Yang
Author: Dustin Kendall
Assignment: 3
File Name:Student.java
Date: 3.24.2018
*/
// Student Class is the class which creates stores and modifies student information*/
import java.util.*;

public class Student {
	private String name;
	private int year;
	private int studentNumber;
	private ArrayList<Course> courses = new ArrayList<>(4);
	
	public Student() {
		name = "John Doe";
		year = 1990;
		studentNumber= 000000000;
		courses = null;
	}
	public Student(String aName, int aYear, int aStudentNumber) {
		name = aName;
		year = aYear;
		studentNumber = aStudentNumber;
		
		
	}
	
	public String getName() {
		return name;
	}
	public int getYear() {
		return year;
		
	}
	public int getStudentNumber() {
		return studentNumber;
	}
	public String toString() {
		return (name+" #"+studentNumber+" ("+year+")");
	}
	public ArrayList<Course> getCourses() {
		
		return courses;
		
	}
	public void addCourse(Course c)
	{
		courses.add(c);
	}
	public void removeCourse(Course c) {
		
		courses.remove(c);
	}
	public ArrayList<Student> classmatesAt(University u){
		ArrayList<Student> students = new ArrayList<>(u.getStudents());
		Iterator<Student> s = students.iterator();
		while(s.hasNext()) {
			if((s.next()).equals(this)) {
				s.remove();
			}
		}
		return students;
		//finish this part then test.
	}
}
