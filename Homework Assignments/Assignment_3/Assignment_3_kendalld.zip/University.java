/*
Class: ECE25100 Object Oriented Programming
Instructor: Xiaoli Yang
Author: Dustin Kendall
Assignment: 3
File Name:University.java
Date: 3.24.2018
*/
import java.util.*;
public class University {
		private String name;
		private ArrayList<Course> coursesOffered = new ArrayList<>(200);//Courses offered at university
		private ArrayList<Student> studentsEnrolled  = new ArrayList<>(1000);//Students enrolled at said university
		public University(String n) {
			name = n;
		}
		public String getName() {
			return name;
		}
		public ArrayList<Course> getCourses(){
			return coursesOffered;
		}
		public ArrayList<Student> getStudents(){
			return studentsEnrolled;
		}
		public void offerCourse(Course c) {
			coursesOffered.add(c);
		}
		public void cancelCourse(Course c) {
			//try to get element zero if there is an exception means there
			//are no students enrolled in the class and you can remove the class
			try{
			c.getStudents().get(0);
			} 
			catch(IndexOutOfBoundsException e){
			coursesOffered.remove(c);
			}
		}
		
		public void enrollStudentInCourse(Student s, Course c) {
			boolean studentExistsAlready = false;
			boolean studentEnrolled = false;
			if(s!=null&&c!=null)// make sure null objects are not passed
			{
			boolean courseExists = false;
			for(Course cO: coursesOffered)
			{
				if(cO.equals(c))
				{
					courseExists = true;
				}
			}
			for(Student stud : c.getStudents()) {
				if(stud.equals(s))
				{
					studentExistsAlready= true;
				}
			}
			for(Student stud : studentsEnrolled) {
				if(stud.equals(s))
				{
					studentEnrolled = true;
				}
			}
			if(courseExists&&(!studentExistsAlready)) {
			s.addCourse(c);
			c.addStudent(s);
			if(!studentEnrolled)
			{
				studentsEnrolled.add(s);
			}
			
			}
			else {
				System.out.println("Student already exists or Course does not exist");
			}
			}
			
			
			
			//Make sure we do not add students to courses which do not exist.
		}
		//Withdraws students from course and removes course from students schedule
		public void withdrawStudentFromCourse(Student s, Course c) {
			boolean studentRegistered = false;
			for(Student stud: c.getStudents())
			{if(s.equals(stud)) {
				studentRegistered = true;}
			}
			if(s!=null&&c!=null&&studentRegistered)
			{
			s.removeCourse(c);
			c.removeStudent(s);
			}
			//Must not allow student to withdraw from course he is not registered in 
		}
		public String toString() {
			return (name+ ": " + coursesOffered.size() +" Courses," + studentsEnrolled.size()+" Students");
		}
		//Returns courses with lower than specified amount of enrolled students
		public ArrayList<Course> lowRegistrationCourses(int min){
			ArrayList<Course> minCourses = new ArrayList<Course>(coursesOffered);
			//Iterator<Course> minC = minCourses.iterator();
			//
			for(Course c : coursesOffered)
			{
				if(c.getStudents().size()>min)
				{
				 minCourses.remove(c);	
				}
			}
			//did not need an iterator because we removed them from copied ArrayList
			/*while(minC.hasNext())
			{
				if((((Course)minC.next()).getStudents()).size()<=min)
				{
				 minCourses.add(minC);	
				}
			}*/
			return minCourses;
		}
		//returns course with the most students
		public Course highestEnrollment() {
			Course hE =  coursesOffered.get(0);
			for(Course cn : coursesOffered)
			{
				hE = ((hE.getStudents()).size()<(cn.getStudents()).size())?cn : hE;
				
			}
			return hE;
		}
		
		//Returns student enrolled in most classes at university
		public Student busiestStudent() {
			Student bS = studentsEnrolled.get(0);
			for(Student cn : studentsEnrolled) {
				bS = ((bS.getCourses()).size()<(cn.getCourses()).size())?cn : bS;
			}
			return bS;
		}
		
}
