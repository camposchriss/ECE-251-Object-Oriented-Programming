import java.util.StringTokenizer;


public class StringEditorTester { 
    public static void main(String args[]) { 
      String original = "Hello, I am working at ECE. How about you ?!!"; 
        System.out.println(StringEditor.removeNonLetters(original)); 
        
    

    } 
} 
