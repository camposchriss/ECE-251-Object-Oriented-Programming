import java.util.*;
public class AutoShow{
	ArrayList<Car> cars;

	public AutoShow(){
		cars=new ArrayList<Car>();
	}

	public ArrayList<Car> getCars(){
		return cars;
	}

	public String toString(){
		return ("The Chicago Autoshow has "+cars.size()+" cars in 2018.");
	}

	public void addACar(Car c){
		cars.add(c);
	}

	public Car topSpeed(){
		Car top=cars.get(0);
		for(Car c: cars){
			if(c.getTopSpeed()>top.getTopSpeed()){
				top=c;
			}

		}
		return top;
	}

	public ArrayList<Car> carsWithMake(String m){
		ArrayList<Car> sameMake=new ArrayList<Car>();
		for(Car c: cars){
			if(c.getMake().equals(m)){
				sameMake.add(c);
				}
		}
		return sameMake;
	}

	public ArrayList<String> differentMakes(){
		ArrayList<String> different=new ArrayList<String>();
		for(Car c: cars){
			String make=c.getMake();
			boolean found=false;
			for(String s: different){
				if(s.equals(make))
					found=true;
			}
			if(!found)
				different.add(make);
			}
		return different;
}

	public void printBySpeed(){
		ArrayList<Car> copy=new ArrayList<Car>(cars);

		while(!copy.isEmpty()){
			Car top=copy.get(0);

			for(Car c: copy){
				if(c.getTopSpeed()>top.getTopSpeed()){
					top=c;
				}
			}
			System.out.println(top);
			copy.remove(top);

		}
	}

	public void printBySpeedSorting(){
		ArrayList<Car> copy=new ArrayList<Car>(cars);
		for(int i=0; i<copy.size(); i++){

		for(int j=0; j<copy.size()-1-i;j++){
			if((copy.get(j)).getTopSpeed()<(copy.get(j+1)).getTopSpeed()){
				Car temp;
				temp=copy.get(j);
				copy.set(j,copy.get(j+1));
				copy.set(j+1,temp);
			}
		}
		}

		for(Car c: copy){
			System.out.println(c);
		}

	}


}