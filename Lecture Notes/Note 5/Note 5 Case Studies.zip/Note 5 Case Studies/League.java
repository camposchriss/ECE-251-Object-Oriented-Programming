
public class League {
	private String name;
	private Team[] teams;
	private int teamCount;

	public League(String n){
		name=n;
		teams=new Team[8];
		teamCount=0;
	}

    public String getName(){
    	return name;
    }
    public Team[] getTeams(){
    	return teams;
    }

    public void setName(String n){
    	name=n;
    }

    public String toString(){
    	return ("The league has "+ teamCount + " teams.");
    }

    public void addTeam(Team aTeam){
    	if (teamCount<8)
    		teams[teamCount++]=aTeam;
    	else
    		System.out.println("no more teams!");
    }

    public void showTeams(){
    	for (int i=0; i<teamCount; i++)
    		System.out.println(teams[i]);
    }

    public void recordWinAndLoss(Team t1, Team t2){
    	t1.setWins(t1.getWins()+1);
    	t2.setLosses(t2.getLosses()+1);
    }

    public void recordTie(Team t1, Team t2){
    	t1.setTies(t1.getTies()+1);
    	t2.setTies(t2.getTies()+1);
    }

    public Team teamWithName(String n){
    	Team t=new Team("");
    	for(int i=0; i<teamCount; i++){
    		if((teams[i].getName()).equals(n))
    			t=teams[i];
    	}
    	return t;
    }

    public int totalGamesPlayed(){
    	int gamesPlayed=0;
    	for(int i=0; i<teamCount; i++){
    		gamesPlayed+=teams[i].gamesPlayed();
    	}
    	return gamesPlayed/2;
    }

    public Team firstPlaceTeam(){
    	Team t=teams[0];
    	for(int i=1; i<teamCount; i++){
    		if(t.totalPoints()<=teams[i].totalPoints())
    			t=teams[i];
    	}
    	return t;
    }

    public Team lastPlaceTeam(){
    	Team t=teams[0];
    	for(int i=1; i<teamCount; i++){
    		if(t.totalPoints()>teams[i].totalPoints())
    			t=teams[i];
    	}
    	return t;
    }

    public void recordWinAndLoss(String s1, String s2){
    	Team t1=teamWithName(s1);
    	Team t2=teamWithName(s2);
    	recordWinAndLoss(t1,t2);
    }

    public void recordTie(String s1, String s2){
    	Team t1=teamWithName(s1);
    	Team t2=teamWithName(s2);
    	recordTie(t1,t2);
    }

}