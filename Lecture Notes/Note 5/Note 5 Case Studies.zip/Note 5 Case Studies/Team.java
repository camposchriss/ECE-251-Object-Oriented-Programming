public class Team {
	private String name;
	private int wins, losses, ties;

	public Team(String n){
		name=n;
		wins=losses=ties=0;
	}

	public Team(){
		this("");
	}

	public String getName(){
		return name;
	}

	public int getWins(){
		return wins;
	}

	public int getTies(){
		return ties;
	}

	public int getLosses(){
		return losses;
	}

	public void setName(String n){
		name=n;
	}

	public void setWins(int n){
		wins=n;
	}

	public void setLosses(int n){
		losses=n;
	}

	public void setTies(int n){
		ties=n;
	}

	public String toString(){
		return ("The team "+name + " has " + wins +" wins, "+ties +" ties, and "+losses +" losses.");
	}

	public int totalPoints(){
		return (wins*2+ties);
	}

	public int gamesPlayed(){
		return wins+losses+ties;
	}




}