public class DayConverterTester {
    public static void main(String args[]) {
        for (int i=1; i<=8; i++)
            System.out.println("Day " + i + " is " + DayConverter.dayOfWeek(i) + ".");
    }
}

