public class DayConverter {
    public static String dayOfWeek(int dayNumber) {
        String days[] = {"Sunday", "Monday", "Tuesday", "Wednesday",
                         "Thursday", "Friday", "Saturday"};
        if ((dayNumber < 1) || (dayNumber > 7))
            return "Invalid";
        return days[dayNumber-1];
    }
} 