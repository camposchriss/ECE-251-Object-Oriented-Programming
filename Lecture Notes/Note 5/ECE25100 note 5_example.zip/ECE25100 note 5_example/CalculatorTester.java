public class CalculatorTester {
 
    public static void printArray(int anArray[]) {
        System.out.print("(");
        for (int i=0; i<anArray.length; i++)
            System.out.print(anArray[i] + " ");
        System.out.println(")");
    }
    public static void main(String args[]) {
        int     testArray[] = {5, 10, 15, 20, 25};
        
        System.out.println("The maximum is " + Calculator.findMaximum(testArray));
        System.out.println("The average is " + Calculator.calculateAverage(testArray));
        int factor = 2;

        System.out.print("The original Array is "); printArray(testArray);
   		Calculator.scale(testArray, factor);
        System.out.print("The modified Array is "); printArray(testArray);
        
        
    }
    
}