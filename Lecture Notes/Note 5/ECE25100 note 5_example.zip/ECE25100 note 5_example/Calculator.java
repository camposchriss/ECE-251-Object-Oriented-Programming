public class Calculator {
    public static double calculateAverage(int[] numbers) {
        int sum = 0;
        for (int i=0; i<numbers.length; i++)
            sum += numbers[i];
        return sum/(double)numbers.length;
    }
    
     public static int findMaximum(int[] numbers) {
        int max = numbers[0];
        for (int i=0; i<numbers.length; i++)
            if (numbers[i] > max)
                max = numbers[i];
        return max;
    }
    
     public static void scale(int[] numbers, int factor) {
        for (int i=0; i<numbers.length; i++)
            numbers[i] = numbers[i] * factor;
         
    }
} 