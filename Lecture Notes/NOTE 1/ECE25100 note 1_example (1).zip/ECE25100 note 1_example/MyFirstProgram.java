public class MyFirstProgram {
    public static void main(String[] args){
        //print out the words Hello Everyone to the console
        System.out.println("Hello world.");
    }
} 
