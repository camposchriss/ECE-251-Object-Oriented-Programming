public class ComputeAreaTest {
  /** Main method */
  public static void main(String[] args) {
    ComputeArea computeArea = new ComputeArea();
    computeArea.compute();
  }
}
