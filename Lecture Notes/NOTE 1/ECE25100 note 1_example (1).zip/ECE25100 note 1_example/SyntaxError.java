public class SyntaxError {
  public static void main(String[] args) {
    i = 30;
    System.out.println(i + 4);
  }
}

