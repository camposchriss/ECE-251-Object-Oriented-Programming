import java.io.*;

public class AutoshowSaveLoadTest {
    // This method tests the writing of an autoshow to a file
    private static void writeTest() throws IOException {
   	  	// First make an Autoshow and add lots of cars to the show
        Autoshow  show = new Autoshow("Chicago Autoshow 2018");
        show.addCar(new Car("Porsche", "959", "Red", 240));
        show.addCar(new Car("Pontiac", "Grand-Am", "White", 160));
        show.addCar(new Car("Ford", "Mustang", "White", 230));
        show.addCar(new Car("Volkswagon", "Beetle", "Blue", 140));
        show.addCar(new Car("Volkswagon", "Jetta", "Silver", 180));
        show.addCar(new Car("Geo", "Storm", "Yellow", 110));
        show.addCar(new Car("Toyota", "MR2", "Black", 220));
        show.addCar(new Car("Ford", "Escort", "Yellow", 10));
        show.addCar(new Car("Honda", "Civic", "Black", 220));
        show.addCar(new Car("Nissan", "Altima", "Silver", 180));
        show.addCar(new Car("BMW", "5", "Gold", 260));
        show.addCar(new Car("Prelude", "Honda", "White", 90));
        show.addCar(new Car("Mazda", "RX7", "Red", 240));
        show.addCar(new Car("Mazda", "MX6", "Green", 160));
        show.addCar(new Car("Pontiac", "G6", "Black", 140));

   	  	// Now open the file and save the autoshow
	  	PrintWriter    	aFile;
	  	aFile = new PrintWriter(new FileWriter("autoshow.txt"));
        show.saveTo(aFile);
        aFile.close();
    }

    // This method tests the reading of an autoshow from a file
    private static void readTest() throws IOException {
        BufferedReader  aFile;

        aFile = new BufferedReader(new FileReader("autoshow.txt"));
        Autoshow aShow = Autoshow.loadFrom(aFile);
        aShow.showCars();
        aFile.close();
    }

    public static void main(String[] args) throws IOException {
        writeTest(); 	// Write an autoshow to the file
        readTest(); 	// Read an autoshow from the file
    }
}
