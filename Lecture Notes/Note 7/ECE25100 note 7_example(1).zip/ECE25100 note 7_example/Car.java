import java.io.*;
import java.util.*;

public class Car {
	private String	 make;
	private String	 model;
	private String	 color;
	private int	 	 topSpeed;

	public Car() {
		this("","","",0);
	}

	public Car(String mak, String mod, String col, int tsp) {
		make = mak;
		model = mod;
		color = col;
		topSpeed = tsp;
	}

	public String toString() {
		return (make + " " + model + " with top speed " + topSpeed + "mph");
	}

	public void saveTo(PrintWriter aFile) {
	    aFile.println(make);
	    aFile.println(model);
	    aFile.println(color);
	    aFile.println(topSpeed);
	}

	public static Car loadFrom(BufferedReader aFile) throws IOException {
	    Car  loadedCar = new Car();

	    loadedCar.make = aFile.readLine();
	    loadedCar.model = aFile.readLine();
	    loadedCar.color = aFile.readLine();
	    loadedCar.topSpeed = Integer.parseInt(aFile.readLine());

	    return loadedCar;
	}

	public void saveTo2(PrintWriter aFile) {
	    aFile.println(make + "," + model + "," + color + "," + topSpeed );
	}

	public static Car loadFrom2(BufferedReader aFile) throws IOException {
	    Car  loadedCar = new Car();

	    StringTokenizer wholeLine = new StringTokenizer(aFile.readLine(),",");
	    loadedCar.make = wholeLine.nextToken();
	    loadedCar.model = wholeLine.nextToken();
	    loadedCar.color = wholeLine.nextToken();
	    loadedCar.topSpeed = Integer.parseInt(wholeLine.nextToken());

	    return loadedCar;
	}

}
