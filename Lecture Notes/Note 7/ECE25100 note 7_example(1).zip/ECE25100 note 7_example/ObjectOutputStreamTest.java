import java.io.*;

public class ObjectOutputStreamTest {
    public static void main(String args[]) {
        try {
            BankAccount  		aBankAccount;
            ObjectOutputStream	out;

		 	aBankAccount = new BankAccount("Rachel");
		 	aBankAccount.deposit(100);

            out = new ObjectOutputStream(new FileOutputStream("myAccount3.dat"));
            out.writeObject(aBankAccount);
            out.close();

        } catch (FileNotFoundException e) {
            System.out.println("Error: Cannot open file for writing");
        } catch (IOException e) {
            System.out.println("Error: Cannot write to file");
        }
    }
}
