import java.io.*;

public class ObjectInputStreamTest {
    public static void main(String[] args) {
        try {
            BankAccount    aBankAccount;
            ObjectInputStream in;

            in = new ObjectInputStream(new FileInputStream("myAccount3.dat"));
            aBankAccount = (BankAccount)in.readObject();

            System.out.println(aBankAccount);
            in.close();

        } catch (ClassNotFoundException e) {
            System.out.println("Error: Object'c class does not match");
        } catch (FileNotFoundException e) {
            System.out.println("Error: Cannot open file for writing");
        } catch (IOException e) {
            System.out.println("Error: Cannot read from file");
        }
    }
}
