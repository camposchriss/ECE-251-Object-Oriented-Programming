public class BankAccount implements java.io.Serializable {
	static int	LAST_ACCOUNT_NUMBER = 100000;

	String		owner;
	int			accountNumber;
	float		balance;

	BankAccount() {	this(""); }
	BankAccount(String ownerName) {
		this.owner = ownerName;
		this.accountNumber = LAST_ACCOUNT_NUMBER++;
		this.balance = 0;
	}
	BankAccount(String ownerName, float bal, int acc) {
		this.owner = ownerName;
		this.accountNumber = acc;
		this.balance = bal;
	}

	public String getOwner() { return owner; }
	public int getAccountNumber() { return accountNumber; }
	public float getBalance() { return balance; }


	public String toString() {
		return "Account #" + accountNumber + " with $" + balance;
	}

	// Deposit money into the account
	void deposit(float amount) {
		balance += amount;
	}

	// Withdraw money from the account
	void withdraw(float amount) {
		if (balance >= amount)
			balance -= amount;
	}
}
