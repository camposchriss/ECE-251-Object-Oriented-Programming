import java.io.*;

public class FileClassTestProgram {
    public static void main(String[] args) {
        // The dot means the current directory
        File currDir = new File("C:\\");
        System.out.println("The directory name is: " + currDir.getName());
        System.out.println("The path name is: " + currDir.getPath());
        System.out.println("The actual path name is: " +
                                                currDir.getAbsolutePath());

        System.out.println("Here are the files in the current directory: ");
        String[]  files = currDir.list();
        for (int i=0; i<files.length; i++) {
            if (new File("C:\\", files[i]).isDirectory())
                 System.out.print("*** ");
            System.out.println(files[i]);
        }
    }
}
