import java.io.*;
public class SystemInTest {
    public static void main(String args[]) {


System.out.print("System.in is an instance of ");
System.out.println(System.in.getClass());
System.out.print("System.out is an instance of ");
System.out.println(System.out.getClass());

}
}
