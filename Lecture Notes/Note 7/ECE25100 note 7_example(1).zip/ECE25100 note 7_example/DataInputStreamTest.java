import java.io.*;

public class DataInputStreamTest {
    public static void main(String[] args) {
        try {
            BankAccount       aBankAccount;
            DataInputStream   in;

            in = new DataInputStream(new FileInputStream("myAccount1.dat"));

            String name = in.readUTF();
            int     acc = in.readInt();
            float   bal = in.readFloat();

            aBankAccount = new BankAccount(name, bal, acc);
            System.out.println(aBankAccount);
            in.close();

        } catch (FileNotFoundException e) {
            System.out.println("Error: Cannot open file for reading");
        } catch (IOException e) {
            System.out.println("Error: Cannot read from file");
        }
    }
}
