import java.io.*;

public class PrintWriterTest{
    public static void main(String[] args) {
        try {
            BankAccount  aBankAccount;
            PrintWriter  out;

		 aBankAccount = new BankAccount("Rachel");
		 aBankAccount.deposit(100);

            out = new PrintWriter(new FileWriter("myAccount2.dat"));

            out.println(aBankAccount.getOwner());
            out.println(aBankAccount.getAccountNumber());
            out.println(aBankAccount.getBalance());
            out.close();

        } catch (FileNotFoundException e) {
            System.out.println("Error: Cannot open file for writing");
        } catch (IOException e) {
            System.out.println("Error: Cannot write to file");
        }
    }
}
