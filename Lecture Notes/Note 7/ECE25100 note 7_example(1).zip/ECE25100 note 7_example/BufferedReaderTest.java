import java.io.*;

public class BufferedReaderTest {
    public static void main(String args[]) {
        try {
            BankAccount      aBankAccount;
            BufferedReader   in;

            in  = new BufferedReader(new FileReader("myAccount2.dat"));
            String name = in.readLine();
            int     acc = Integer.parseInt(in.readLine());
            float   bal = Float.parseFloat(in.readLine());

            aBankAccount = new BankAccount(name, bal, acc);
            System.out.println(aBankAccount);
            in.close();

        } catch (FileNotFoundException e) {
            System.out.println("Error: Cannot open file for reading");
        } catch (IOException e) {
            System.out.println("Error: Cannot read from file");
        }
    }
}
