import java.util.Scanner;

public class SuperCalculator {
    public void averageThreeFromUser() {
        int       a, b, c, sum;
        Scanner   keyboard = new Scanner(System.in);

        System.out.println("Enter three numbers:");
        a = keyboard.nextInt();
        b = keyboard.nextInt();
        c = keyboard.nextInt();

        sum = a + b + c;    //compute the sum and store it
        System.out.println("Given numbers " + a + ", " + b + " and " + c + ": ");
        System.out.println("The sum is " + sum);
        System.out.println("The product is " + (a * b * c));
        System.out.println("The average is " + (sum / 3));
    }
}

