public class PrintfFlagTester {
    public static void main(String args[]) {
        System.out.printf("Right Justified %8.2f %n", 256.678394);   
        System.out.printf("Left  Justified %-8.2f %n", 256.678394);   
        System.out.printf("Leading zeros %08.2f %n", 256.678394);   
        System.out.printf("Leading zeros %06d %n", 1234);   
        System.out.printf("Plus sign on positive value %+8.2f %n", 256.678394);   
        System.out.printf("Plus sign on negative value %+8.2f %n", -256.678394);   
        System.out.printf("Brackets on Positive value %(8.2f %n", 256.678394);   
        System.out.printf("Bracekts on Negative value %(8.2f %n", -256.678394);   
        System.out.printf("Big number without separators %8.2f %n", 2567896.82);   
        System.out.printf("Big number with separators %,8.2f %n", 2567896.82);   
    }
}

