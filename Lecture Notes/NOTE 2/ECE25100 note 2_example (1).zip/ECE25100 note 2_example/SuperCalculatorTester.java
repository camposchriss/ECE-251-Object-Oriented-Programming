public class SuperCalculatorTester {
    public static void main(String args[]) {
        new SuperCalculator().averageThreeFromUser();
    }
} 
