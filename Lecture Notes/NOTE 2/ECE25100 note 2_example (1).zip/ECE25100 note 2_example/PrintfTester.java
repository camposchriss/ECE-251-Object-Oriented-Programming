public class PrintfTester {
    public static void main(String args[]) {
        System.out.printf("Two dollars is $%4.2f %n", 2.00);   
        System.out.printf("Truncated to two decimal places shows as %4.2f %n", 256.678394);   
        System.out.printf("Leading spaces shows as %8.2f %n", 256.678394);   
        System.out.printf("Four decimal places is %4.4f %n", 256.678394);   
        System.out.printf("255 as a Decimal Integer is shown as %d %n", 255);   
        System.out.printf("255 as an Octal Integer is shown as %o %n", 255);   
        System.out.printf("255 as a Hexadecimal Integer is shown as %x or %X %n", 255, 255);
        System.out.printf("0.00786987698 as an exponential floating point is shown as %e %n", 0.00786987698);   
        System.out.printf("0.00786987698 as a general floating point with 1 sig. dig. is shown as %1.1g %n", 0.00786987698);   
        System.out.printf("82.10786987698 as a general floating point with 1 sig. dig. is shown as %1.1g %n", 82.10786987698);   
        System.out.printf("0.00786987698 as a fixed floating point is shown as %1.1f %n", 0.00786987698);   
        System.out.printf("255 as a Boolean is shown as %b or %B %n", true, false);   
        System.out.printf("A is shown as %s or %S %n", "Two Fifty Five","Two Fifty Five");
    }
}

