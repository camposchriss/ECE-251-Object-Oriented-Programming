public class SystemPrintTest {
    public static void main(String args[]) {
       
      char  a = 'M';
    char  b = 'A', c = 'R', d = 'Y'; 
	System.out.println("My name is: " + a + b + c + d);
	b = 'E';
	c = 'I';
	d = 'K';
	{	System.out.println("The mystery name is: " + a + c + d + b);}


	float f=9.67f;
	System.out.println("The float number is: " + f);
	
	double dNumber=5.67890;
	System.out.println("The double number is: " + dNumber);

	boolean bNumber=true;
	System.out.println("The boolean number is: " + bNumber);

    }
    
 

} 