import java.util.*;
public class GuessANumber{
	public static void main(String[] args){
		int number=(int)(Math.random()*100+1);
		System.out.println(number);
		Scanner s=new Scanner(System.in);

		System.out.println("Please enter a value 1-100: ");
		int guess=s.nextInt();
		int tries=1;
		while(guess!=number){
			if(guess>number)
			{
				System.out.println("Lower! ");
			}
			else
				System.out.println("Higher! ");
		System.out.println("Please enter a value 1-100: ");
		guess=s.nextInt();
			tries++;
		}

		System.out.println("Congratulations, you guessed the number right after " + tries +" tries!");

	}

}