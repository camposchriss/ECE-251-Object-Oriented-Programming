public class RealNumberComparison{
	public static void main(String[] args){
		double data = Math.pow(Math.sqrt(2), 2) - 2;
		double eps=1E-12;
	//if (data == 0)
	if(data<eps)
 	 System.out.println("data is zero");
	else
  	System.out.println("data is not zero");

	}
}