import java.util.Scanner;

public class MultipleIf2Tester
{
	public static void main(String args[]) {


	double score;
	char grade;

	System.out.println("Please enter a score:");
	score = new Scanner(System.in).nextDouble();

/*
	if(score >= 90.0)
		grade = 'A';
	else if(score >= 80.0)
		grade = 'B';
	else if(score >= 70.0)
		grade = 'C';
	else if(score >= 60.0)
		grade = 'D';
	else
		grade = 'F';

			if(score >= 60.0&&score < 70.0)
		grade = 'D';
	else if(score >= 70.0&&score < 80.0)
		grade = 'C';
	else if(score >= 80.0&&score < 90.0)
		grade = 'B';
	else if(score >= 90.0)
		grade = 'A';
	else
		grade = 'F';*/

		if(score >= 90.0)
		grade = 'A';
	 if(score >= 80.0)
		grade = 'B';
 if(score >= 70.0)
		grade = 'C';
	 if(score >= 60.0)
		grade = 'D';
	else
		grade = 'F';

			System.out.println("Your final grade is: "+grade);
	}

}