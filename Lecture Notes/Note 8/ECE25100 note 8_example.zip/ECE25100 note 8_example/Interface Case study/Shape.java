
// Definition of interface Shape

public interface Shape {
   public abstract double area();
   public abstract double volume();
   public abstract String getName();   
} // end interface Shape
