public class Person  { 
    public String name; 
    public String getName(){ 
        return name; } 
        
    public void setName(String aName){
    	name = aName;
    }
    
    public static void p(){
    	System.out.println("I am in Person class");
    }
} 
