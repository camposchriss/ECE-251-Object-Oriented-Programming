/****************      Step 8        **********************/
public class Employee extends Person {

protected int       employeeNumber;
protected String    workPhoneNumber; 


protected int regularHoursWorked = 40;
protected int overTimeHoursWorked = 20;
protected float payRate = 9.0f;


/**************    constructor method    *****************/
public Employee() {
    this(0, "");
}


public Employee(int aNumber, String aPhoneNumber) { 
setEmployeeNumber(aNumber);
setWorkPhoneNumber(aPhoneNumber); 
} 


/**************    get and set methods   ****************/
public int getEmployeeNumber(){
	return employeeNumber;
}

public String getWorkPhoneNumber(){
	return workPhoneNumber;
}

public int getRegularHoursWorked(){
	return regularHoursWorked;
}

public int getOverTimeHoursWorked(){
	return overTimeHoursWorked;
}

public float getPayRate(){
	return payRate;
}

public void setEmployeeNumber(int aNumber){
	employeeNumber = aNumber;
}

public void setWorkPhoneNumber(String aPhoneNumber){
	workPhoneNumber = aPhoneNumber;
}

public void setRegularHoursWorked(int hours){
	regularHoursWorked = hours;
}

public void setOverTimeHoursWorked(int hours){
	overTimeHoursWorked = hours;
}

public void setPayRate(float rate){
	payRate = rate;
}

//This is the toString method for the Employee class
public String toString() { 
return(super.toString() +"\n" + 
"  EMPLOYEE #: " + getEmployeeNumber() + "\n" +
"  WORK #:     " + getWorkPhoneNumber()); 

}


public float computePay()  { 
  return (regularHoursWorked * payRate) + 
           (overTimeHoursWorked * 1.5f * payRate); 
} 

public static float expenseAllowance(){
	return 10.0f;
}

public static void p(){
    	System.out.println("I am in Employee class");
    }
} 
