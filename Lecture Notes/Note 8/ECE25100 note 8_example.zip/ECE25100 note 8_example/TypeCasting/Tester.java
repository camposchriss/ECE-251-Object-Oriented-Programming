public class Tester{
	public static void main(String[] args){	
	
/*	Employee jim = new Employee(); 
	jim.name = "Jim"; 
	jim.employeeNumber = 123456; 
	System.out.println(jim.getName());
	System.out.println(jim.getEmployeeNumber()); 

	Manager betty = new Manager(); 
	betty.name = "Betty"; 
	betty.employeeNumber = 543469; 
	betty.responsibilities.add("Internet project"); 
	System.out.println('\n'+betty.getName()); 
	System.out.println(betty.getEmployeeNumber());
	
	Manager   man = new Manager(); 
	man.setName("Frank");
	System.out.println('\n'+ man.getName());
	System.out.println(man.getEmployeeNumber()); 
	System.out.println(man.computePay()); 
	
	Employee  emp = (Employee)man; 
	System.out.println('\n'+emp.getName());
	System.out.println(emp.getEmployeeNumber()); 
	System.out.println(emp.computePay());
//	System.out.println(emp.getSalary());
	
	System.out.println();
	System.out.println(((Manager)emp).computePay());
	System.out.println(((Manager)emp).getSalary());
	
	Manager   man = new Manager(); 
	Employee  emp1 = new Employee(); 
	Employee  emp2 = (Employee)man; 
	System.out.println(emp1.computePay());  
	System.out.println(man.computePay());   
	System.out.println(emp2.computePay()); 
//	System.out.println(emp2.getSalary());
	System.out.println();
	
	System.out.println(Manager.expenseAllowance());  
	System.out.println(man.expenseAllowance()); 
	System.out.println();      

	System.out.println(Employee.expenseAllowance()); 
	System.out.println(emp1.expenseAllowance());     
	System.out.println(emp2.expenseAllowance());
	System.out.println();  */  
		
		Employee e = new Employee();
		Person per = e;
		
		per.p();	
	}
}