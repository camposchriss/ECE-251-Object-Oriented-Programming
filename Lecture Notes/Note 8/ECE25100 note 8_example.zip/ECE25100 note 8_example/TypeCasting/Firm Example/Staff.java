class Staff {

   Staff_Member[] staff_list = new Staff_Member[6];

   /*
   *  Sets up the list of staff members.
   */
   public Staff() {

      staff_list[0] = new Executive ("Sam", "123 Main Line",
         "555-0469", "123-45-6789", 1923.07);
      staff_list[1] = new Employee ("Carla", "456 Off Line",
         "555-0101", "987-65-4321", 846.15);
      staff_list[2] = new Employee ("Woody", "789 Off Rocker",
         "555-0000", "010-20-3040", 769.23);
      staff_list[3] = new Hourly ("Diane", "678 Fifth Ave.",
         "555-0690", "958-47-3625", 8.55);
      staff_list[4] = new Volunteer ("Norm", "987 Suds Blvd.",
         "555-8374");
      staff_list[5] = new Volunteer ("Cliff", "321 Duds Lane",
         "555-7282");

      ((Executive)staff_list[0]).award_bonus (5000);
      ((Hourly)staff_list[3]).add_hours (40);

   }  

   /*
   *  Pays all staff members.
   */
   public void payday() {

      double amount;

      for (int count=0; count < staff_list.length; count++) {
         staff_list[count].print();
         amount = staff_list[count].pay();
         if (amount == 0.0)
            System.out.println ("Thanks!");
         else
            System.out.println ("Paid: " + amount);
         System.out.println ("**********************");
      }

   }  

}  