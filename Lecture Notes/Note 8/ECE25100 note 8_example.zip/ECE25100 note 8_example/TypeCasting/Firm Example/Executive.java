class Executive extends Employee {

   private double bonus;

   /*
   *  Sets up an executive using the specified information.
   */
   public Executive (String exec_name, String exec_address,
                     String exec_phone, String exec_ssnumber,
                     double exec_rate) {

      super (exec_name, exec_address, exec_phone, exec_ssnumber,
             exec_rate);

      bonus = 0;  

   } 

   /*
   *  Awards the specified bonus to this executive.
   */
   public void award_bonus (double exec_bonus) {
      bonus = exec_bonus;
   } 

   /*
   *  Computes and returns the pay for this executive, which
   *  includes a possible bonus.
   */
   public double pay () {
      double paycheck = super.pay() + bonus;
      bonus = 0;
      return paycheck;
   }  

   /*
   *  Prints information about this executive, using the
   *  print method from the parent class.
   */
   public void print () {
      super.print();
      System.out.println ("Current bonus: " + bonus);
   } 

}  