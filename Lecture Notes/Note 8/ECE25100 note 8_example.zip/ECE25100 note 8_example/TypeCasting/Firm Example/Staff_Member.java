class Staff_Member {

   protected String name;
   protected String address;
   protected String phone_number;

   /*
   *  Sets up a staff member using the specified information.
   */
   public Staff_Member (String emp_name, String emp_address,
          String emp_phone) {

      name = emp_name;
      address = emp_address;
      phone_number = emp_phone;

   }  

   /*
   *  Establishes a pay method so that all staff members can
   *  get paid.  This method is overridden in derived classes.
   */
   public double pay() {
      return 0.0;
   }  

   /*
   *  Prints the basic information for any staff member.
   */
   public void print() {
      System.out.println ("Name: " + name);
      System.out.println ("Address: " + address);
      System.out.println ("Phone: " + phone_number);
   }  

}  

