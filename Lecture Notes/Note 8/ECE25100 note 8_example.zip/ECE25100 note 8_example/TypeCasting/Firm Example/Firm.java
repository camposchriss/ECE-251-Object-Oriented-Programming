class Firm {

   /*
   *  Creates a staff and pays them.
   */
   public static void main (String[] args) {

      Staff personnel = new Staff();

      personnel.payday();

   }  

}  
