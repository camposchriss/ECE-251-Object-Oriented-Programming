class Volunteer extends Staff_Member {

   /*
   *  Sets up a volunteer using the specified information.
   */
   public Volunteer (String emp_name, String emp_address,
          String emp_phone) {

      super (emp_name, emp_address, emp_phone);

   }  

   
}  
