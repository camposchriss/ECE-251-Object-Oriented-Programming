class Employee extends Staff_Member {

   protected String social_security_number;
   protected double pay_rate;
   
   /*
   *  Sets up an employee using the specified information.
   */
   public Employee (String emp_name, String emp_address,
          String emp_phone, String emp_ssnumber, double emp_rate) {

      super (emp_name, emp_address, emp_phone);
      social_security_number = emp_ssnumber;
      pay_rate = emp_rate;

   }  

   /*
   *  Returns the pay rate for this employee.  Overrides the
   *  parent's pay method._rate = emp_rate;
   */
   public double pay () {
      return pay_rate;
   }  

   /*
   *  Prints information about this employee, using the
   *  print method from the parent class.
   */
   public void print () {
      super.print();
      System.out.println ("SS number: " + social_security_number);
      System.out.println ("Pay rate: " + pay_rate);
   }  

}  