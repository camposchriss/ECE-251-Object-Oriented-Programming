class Hourly extends Employee {

   private int hours_worked;

   /*
   *  constructor Hourly
   *  Sets up an hourly employee using the specified information.
   */
   public Hourly (String hr_name, String hr_address,
          String hr_phone, String hr_ssnumber, double hr_rate) {

      super (hr_name, hr_address, hr_phone, hr_ssnumber, hr_rate);
      hours_worked = 0;

   }  

   /*
   *  Adds the specified number of hours to this employee's
   *  accumulated hours.
   */
   public void add_hours (int more_hours) {
      hours_worked += more_hours;
   }  
   
   /*
   *  Computes and returns the pay for this hourly employee.
   */
   public double pay () {
      return pay_rate * hours_worked;
   }  

   /*
   *  Prints information about this hourly employee, using
   *  the print method from the parent class.
   */
   public void print () {
      super.print();
      System.out.println ("Current hours: " + hours_worked);
   } 
}  