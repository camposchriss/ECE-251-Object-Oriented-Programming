import java.util.Vector;

public class Manager  extends Employee  {  
    public Vector responsibilities; 
    public float yearlySalary=100000.0f;
        
    public Vector getResponsibilities(){  
        return responsibilities; } 
        
    public float getYearlySalary(){
    	return yearlySalary;
    }
    
    public void setYearlySalary(float salary){
    	yearlySalary = salary;
    }
        
    public float computePay()  { 
    return (yearlySalary / 26f); //26 pay checks per year 
	} 
		
	public float getSalary(){
		return yearlySalary;
	}
	
	public static float expenseAllowance(){
	return 100.0f;
}
	
}