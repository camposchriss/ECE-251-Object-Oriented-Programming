public class TestAB{
	public static void main(String[] args){
	A newA = new A();
	B newB = new B();
	newA.tryVariables();
}
}