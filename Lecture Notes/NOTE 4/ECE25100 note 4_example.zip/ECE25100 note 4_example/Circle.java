public class Circle {
    static double PI = 3.8;
    int radius;
    
    Rectangle r1=new Rectangle();

   /* The method is for Circumference.java */
    public double circumference() {
        double circum = 2 * PI * radius;
        return circum;
   //     return 2 * PI * radius;
  //      return 2 * this.PI * this.radius;
    }


   /* The method is for AreaTester.java */
    public double area() {
    return PI * radius * radius;
	}


	/* The method is for EnlargeTester.java */
	public void enlarge(int factor) {
    radius = radius * factor;
    
    fitsInside(r1);
	}


	/* The method is for FitsInsideTester.java*/
	public  boolean fitsInside(Rectangle r) {
    if ((2*radius >= r.width) || (2*radius >= r.height)) {
        return false;
    }
    return true;
	}
	/* The fitsInside method is simplied */
	/*public boolean fitsInside(Rectangle r) {
    return (2*radius < r.width) && (2*radius < r.height);
	} */

}
