public class AppleTester { 
public static void main(String args[]) {
    // Create two new Apple objects:
    Apple a = new Apple("red", true);
    Apple b = new Apple("red", true); 
    // Is a EQUAL to b ?
    System.out.println(a + " is equal to " + b + ": " + a.equals(b));

    // Are a and b IDENTICAL ?
    System.out.println("a is identical to b: " + (a == b));

    // Another apple object:
    Apple c = a;

    // Is a EQUAL to c ?
    System.out.println(a + " is equal to " + c + ": " + a.equals(c));

    // Are a and c IDENTICAL ?
    System.out.println("a is identical to c: " + (a == c));
}

} 
