import java.util.*;
public class Converter{
      public static void centigradeToFahrenheit (){
      	System.out.println ("Enter a centigrade temperature:");
int cent = new Scanner(System.in).nextInt();
int fahr = cent * 9 / 5 + 32;
System.out.println(" C is " +cent + "F is "+ fahr);
       }
}

