public class ConverterTester{
      public static void main(String args[]){
	Converter.centigradeToFahrenheit();
	Converter c=new Converter();
	c.centigradeToFahrenheit();
      }
}
