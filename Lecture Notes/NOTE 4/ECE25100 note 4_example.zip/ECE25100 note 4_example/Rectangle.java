public class Rectangle {
    double width;
    double height;

    public double area() {
        return width * height;
    }
}

