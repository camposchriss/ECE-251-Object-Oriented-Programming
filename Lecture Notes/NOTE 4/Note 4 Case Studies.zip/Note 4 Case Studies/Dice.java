public class Dice{
	private static int NUM_SIDES;
	private int sum;

	public Dice(int a){
	NUM_SIDES=a;
	}

	public int getSum(){
		return sum;
	}

	public void setSum(int a){
		sum=a;
	}

	public int roll(){
		sum=(int)(Math.random()*NUM_SIDES+1);
		return sum;
	}
}