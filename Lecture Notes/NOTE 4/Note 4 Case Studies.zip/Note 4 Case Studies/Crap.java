public class Crap{
	public static void main(String[] args){
		PairOfDice d=new PairOfDice(6,6);
		Status s=d.testOurLuck();
		if(s==Status.WIN){
			System.out.println("WIN!!!");
		}
		else
			System.out.println("YOU LOSER!");
	}
}