public enum Status{
	WIN, LOSE, CONTINUE;
}