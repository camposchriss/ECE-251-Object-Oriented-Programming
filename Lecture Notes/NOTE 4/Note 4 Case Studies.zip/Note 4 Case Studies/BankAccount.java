public class BankAccount{
/*	private String ownerName;
	private int accountNumber;
	private double balance;

	public BankAccount(String o, int a){
		this(o,a,0.0);
	}
	public BankAccount(String o){
		this(o,0,0.0);
	}
	public BankAccount(){
		this("",0,0.0);
	}
	public BankAccount(String ownerName, int accountNumber, double b){
		this.ownerName=ownerName;
		this.accountNumber=accountNumber;
		balance=b;
	}

	public String getOwnerName(){
		return ownerName;
	}

	public int getAccountNumber(){
		return accountNumber;
	}

	public double getBalance(){
		return balance;
	}

	public void setOwnerName(String o){
		ownerName=o;
	}

	public void setAccountNumber(int o){
		accountNumber=o;
	}

	public void setBalance(double o){
		balance=o;
	}


	public double deposit(double b){
		balance+=b;
		return balance;
	}

	public void withdraw(double b){
		if(b<=balance)
			balance-=b;
			else
				System.out.println("No way");
	}

*/
	public static int LAST_ACCOUNT_NUMBER=0;
	private String ownerName;
	private int accountNumber;
	private double balance;


	public BankAccount(String o){
		this(o,0.0);
	}
	public BankAccount(){
		this("",0.0);
	}
	public BankAccount(String ownerName, double b){
		this.ownerName=ownerName;
		this.accountNumber=++LAST_ACCOUNT_NUMBER;
		balance=b;
	}

	public String getOwnerName(){
		return ownerName;
	}

	public int getAccountNumber(){
		return accountNumber;
	}

	public double getBalance(){
		return balance;
	}

	public void setOwnerName(String o){
		ownerName=o;
	}

	public void setAccountNumber(int o){
		accountNumber=o;
	}

	public void setBalance(double o){
		balance=o;
	}

	public String toString(){
		return ("Owner Name: "+ownerName + " Account number: "+accountNumber+" balance: "+ balance);
	}

	public double deposit(double b){
		balance+=b;
		return balance;
	}

	public void withdraw(double b){
		if(b<=balance)
			balance-=b;
			else
				System.out.println("No way");
	}

	public static BankAccount example1(){
		BankAccount a=new BankAccount("Celeste", 1000);
		return a;
	}

}