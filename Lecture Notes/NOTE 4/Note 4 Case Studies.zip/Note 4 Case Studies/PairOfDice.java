public class PairOfDice{
	Dice d1, d2;

	public PairOfDice(int a, int b){
		d1=new Dice(a);
		d2=new Dice(b);
	}

	public int roll(){
		return d1.roll()+d2.roll();
	}
/*
	public Status testOurLuck(){
		int number=roll();
		Status s=Status.CONTINUE;
		if(number==7|number==11){
			s=Status.WIN;
		}
		else if(number==2|number==3|number==12){
			s=Status.LOSE;
		}

		while(s==Status.CONTINUE){
			int point=roll();

			if(point==number){
				s=Status.WIN;
			}

			else if(point==7){
				s=Status.LOSE;
			}

		}
		return s;

	}*/

	public Status testOurLuck(){
		int number=roll();
		Status s=Status.CONTINUE;
		if(number==7|number==11){
			s=Status.WIN;
		}
		else if(number==2|number==3|number==12){
			s=Status.LOSE;
		}

		while(s==Status.CONTINUE){
			int point=roll();

			if(point==number){
				s=Status.WIN;
			}

			else if(point==7){
				s=Status.LOSE;
			}
			number=point;
		}
		return s;

	}
}