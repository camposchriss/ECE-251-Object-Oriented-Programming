public class BankAccountTes{
	public static void main(String[] args){
		BankAccount carl=new BankAccount("Carl", 200);
		System.out.println(carl.getOwnerName());
		carl.deposit(100);
		System.out.println(carl.getBalance());

		System.out.println(carl.getAccountNumber());
//		System.out.println(BankAccount.LAST_ACCOUNT_NUMBER);

		BankAccount bob=new BankAccount("Bob");
		System.out.println(bob.getOwnerName());
		bob.deposit(100);
		System.out.println(bob.getBalance());

		System.out.println(bob.getAccountNumber());
	//	System.out.println(BankAccount.LAST_ACCOUNT_NUMBER);

		System.out.println(bob.toString());
		System.out.println(bob.toString());

		System.out.println(BankAccount.example1());
	}

}